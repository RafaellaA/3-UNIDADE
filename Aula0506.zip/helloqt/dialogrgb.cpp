#include "dialogrgb.h"
#include "ui_dialogrgb.h"

DialogRGB::DialogRGB(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogRGB)
{
    ui->setupUi(this);
}

DialogRGB::~DialogRGB()
{
    delete ui;
}
