#ifndef DIALOGRGB_H
#define DIALOGRGB_H

#include <QDialog>

namespace Ui {
class DialogRGB;
}

class DialogRGB : public QDialog
{
    Q_OBJECT

public:
    explicit DialogRGB(QWidget *parent = 0);
    ~DialogRGB();

private:
    Ui::DialogRGB *ui;
};

#endif // DIALOGRGB_H
