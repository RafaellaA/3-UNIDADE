/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "plotter.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionFinaliza;
    QWidget *centralWidget;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QGridLayout *gridLayout;
    QLabel *label;
    QSlider *horizontalSliderAmp;
    QLCDNumber *lcdNumber_2;
    QLabel *label_2;
    QSlider *horizontalSliderFreq;
    QLCDNumber *lcdNumber_3;
    QLabel *label_3;
    QSlider *horizontalSliderVel;
    QLCDNumber *lcdNumber_4;
    QHBoxLayout *horizontalLayout;
    QSlider *horizontalSlider;
    QLCDNumber *lcdNumber;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *plainTextEdit;
    QPushButton *pushButtonCopia;
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QGroupBox *groupBox;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLCDNumber *movex;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QLCDNumber *movey;
    QGroupBox *groupBox_2;
    QWidget *widget3;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_6;
    QLCDNumber *clickx;
    QWidget *widget4;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_7;
    QLCDNumber *clicky;
    Plotter *widgetPlotter;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1198, 744);
        actionFinaliza = new QAction(MainWindow);
        actionFinaliza->setObjectName(QStringLiteral("actionFinaliza"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/resources/save.svg"), QSize(), QIcon::Normal, QIcon::Off);
        actionFinaliza->setIcon(icon);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(11, 9, 881, 601));
        horizontalLayout_3 = new QHBoxLayout(widget);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        horizontalSliderAmp = new QSlider(widget);
        horizontalSliderAmp->setObjectName(QStringLiteral("horizontalSliderAmp"));
        horizontalSliderAmp->setValue(99);
        horizontalSliderAmp->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSliderAmp, 0, 1, 1, 1);

        lcdNumber_2 = new QLCDNumber(widget);
        lcdNumber_2->setObjectName(QStringLiteral("lcdNumber_2"));
        lcdNumber_2->setSegmentStyle(QLCDNumber::Flat);

        gridLayout->addWidget(lcdNumber_2, 0, 2, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        horizontalSliderFreq = new QSlider(widget);
        horizontalSliderFreq->setObjectName(QStringLiteral("horizontalSliderFreq"));
        horizontalSliderFreq->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSliderFreq, 1, 1, 1, 1);

        lcdNumber_3 = new QLCDNumber(widget);
        lcdNumber_3->setObjectName(QStringLiteral("lcdNumber_3"));
        lcdNumber_3->setSegmentStyle(QLCDNumber::Flat);

        gridLayout->addWidget(lcdNumber_3, 1, 2, 1, 1);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        horizontalSliderVel = new QSlider(widget);
        horizontalSliderVel->setObjectName(QStringLiteral("horizontalSliderVel"));
        horizontalSliderVel->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSliderVel, 2, 1, 1, 1);

        lcdNumber_4 = new QLCDNumber(widget);
        lcdNumber_4->setObjectName(QStringLiteral("lcdNumber_4"));
        lcdNumber_4->setSegmentStyle(QLCDNumber::Flat);

        gridLayout->addWidget(lcdNumber_4, 2, 2, 1, 1);


        verticalLayout_3->addLayout(gridLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSlider = new QSlider(widget);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setOrientation(Qt::Horizontal);

        horizontalLayout->addWidget(horizontalSlider);

        lcdNumber = new QLCDNumber(widget);
        lcdNumber->setObjectName(QStringLiteral("lcdNumber"));

        horizontalLayout->addWidget(lcdNumber);


        verticalLayout_3->addLayout(horizontalLayout);


        verticalLayout_4->addLayout(verticalLayout_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        plainTextEdit = new QPlainTextEdit(widget);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));

        verticalLayout->addWidget(plainTextEdit);

        pushButtonCopia = new QPushButton(widget);
        pushButtonCopia->setObjectName(QStringLiteral("pushButtonCopia"));

        verticalLayout->addWidget(pushButtonCopia);

        textEdit = new QTextEdit(widget);
        textEdit->setObjectName(QStringLiteral("textEdit"));

        verticalLayout->addWidget(textEdit);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout->addItem(horizontalSpacer);


        verticalLayout_2->addLayout(verticalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        groupBox = new QGroupBox(widget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        widget1 = new QWidget(groupBox);
        widget1->setObjectName(QStringLiteral("widget1"));
        widget1->setGeometry(QRect(10, 30, 78, 25));
        horizontalLayout_4 = new QHBoxLayout(widget1);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(widget1);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_4->addWidget(label_4);

        movex = new QLCDNumber(widget1);
        movex->setObjectName(QStringLiteral("movex"));

        horizontalLayout_4->addWidget(movex);

        widget2 = new QWidget(groupBox);
        widget2->setObjectName(QStringLiteral("widget2"));
        widget2->setGeometry(QRect(10, 80, 78, 25));
        horizontalLayout_5 = new QHBoxLayout(widget2);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(widget2);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout_5->addWidget(label_5);

        movey = new QLCDNumber(widget2);
        movey->setObjectName(QStringLiteral("movey"));

        horizontalLayout_5->addWidget(movey);


        horizontalLayout_2->addWidget(groupBox);

        groupBox_2 = new QGroupBox(widget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        widget3 = new QWidget(groupBox_2);
        widget3->setObjectName(QStringLiteral("widget3"));
        widget3->setGeometry(QRect(20, 30, 78, 25));
        horizontalLayout_6 = new QHBoxLayout(widget3);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(widget3);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_6->addWidget(label_6);

        clickx = new QLCDNumber(widget3);
        clickx->setObjectName(QStringLiteral("clickx"));

        horizontalLayout_6->addWidget(clickx);

        widget4 = new QWidget(groupBox_2);
        widget4->setObjectName(QStringLiteral("widget4"));
        widget4->setGeometry(QRect(20, 80, 78, 25));
        horizontalLayout_7 = new QHBoxLayout(widget4);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(widget4);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_7->addWidget(label_7);

        clicky = new QLCDNumber(widget4);
        clicky->setObjectName(QStringLiteral("clicky"));

        horizontalLayout_7->addWidget(clicky);


        horizontalLayout_2->addWidget(groupBox_2);


        verticalLayout_2->addLayout(horizontalLayout_2);

        verticalLayout_2->setStretch(0, 60);
        verticalLayout_2->setStretch(1, 40);

        verticalLayout_4->addLayout(verticalLayout_2);


        horizontalLayout_3->addLayout(verticalLayout_4);

        widgetPlotter = new Plotter(widget);
        widgetPlotter->setObjectName(QStringLiteral("widgetPlotter"));

        horizontalLayout_3->addWidget(widgetPlotter);

        horizontalLayout_3->setStretch(0, 40);
        horizontalLayout_3->setStretch(1, 60);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1198, 21));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuFile->addAction(actionFinaliza);
        mainToolBar->addAction(actionFinaliza);

        retranslateUi(MainWindow);
        QObject::connect(horizontalSlider, SIGNAL(valueChanged(int)), lcdNumber, SLOT(display(int)));
        QObject::connect(actionFinaliza, SIGNAL(triggered()), MainWindow, SLOT(close()));
        QObject::connect(horizontalSliderAmp, SIGNAL(valueChanged(int)), lcdNumber_2, SLOT(display(int)));
        QObject::connect(horizontalSliderFreq, SIGNAL(valueChanged(int)), lcdNumber_3, SLOT(display(int)));
        QObject::connect(horizontalSliderVel, SIGNAL(valueChanged(int)), lcdNumber_4, SLOT(display(int)));
        QObject::connect(horizontalSliderFreq, SIGNAL(valueChanged(int)), widgetPlotter, SLOT(mudaFrequencia(int)));
        QObject::connect(widgetPlotter, SIGNAL(moveX(int)), movex, SLOT(display(int)));
        QObject::connect(widgetPlotter, SIGNAL(moveY(int)), movey, SLOT(display(int)));
        QObject::connect(widgetPlotter, SIGNAL(clickY(int)), clicky, SLOT(display(int)));
        QObject::connect(widgetPlotter, SIGNAL(clickX(int)), clickx, SLOT(display(int)));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionFinaliza->setText(QApplication::translate("MainWindow", "Finaliza", 0));
#ifndef QT_NO_TOOLTIP
        actionFinaliza->setToolTip(QApplication::translate("MainWindow", "Finaliza o programa", 0));
#endif // QT_NO_TOOLTIP
        actionFinaliza->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", 0));
        label->setText(QApplication::translate("MainWindow", "Amp", 0));
        label_2->setText(QApplication::translate("MainWindow", "Freq", 0));
        label_3->setText(QApplication::translate("MainWindow", "Vel", 0));
        pushButtonCopia->setText(QApplication::translate("MainWindow", ">>>", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Morre!", 0));
        groupBox->setTitle(QApplication::translate("MainWindow", "Move", 0));
        label_4->setText(QApplication::translate("MainWindow", "X", 0));
#ifndef QT_NO_WHATSTHIS
        movex->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        label_5->setText(QApplication::translate("MainWindow", "Y", 0));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Click", 0));
        label_6->setText(QApplication::translate("MainWindow", "X", 0));
        label_7->setText(QApplication::translate("MainWindow", "Y", 0));
#ifndef QT_NO_ACCESSIBILITY
        clicky->setAccessibleName(QString());
#endif // QT_NO_ACCESSIBILITY
#ifndef QT_NO_ACCESSIBILITY
        clicky->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
