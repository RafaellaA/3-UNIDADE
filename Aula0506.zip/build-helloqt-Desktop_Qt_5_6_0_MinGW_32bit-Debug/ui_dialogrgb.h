/********************************************************************************
** Form generated from reading UI file 'dialogrgb.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGRGB_H
#define UI_DIALOGRGB_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_DialogRGB
{
public:
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *DialogRGB)
    {
        if (DialogRGB->objectName().isEmpty())
            DialogRGB->setObjectName(QStringLiteral("DialogRGB"));
        DialogRGB->resize(400, 300);
        buttonBox = new QDialogButtonBox(DialogRGB);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        retranslateUi(DialogRGB);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogRGB, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogRGB, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogRGB);
    } // setupUi

    void retranslateUi(QDialog *DialogRGB)
    {
        DialogRGB->setWindowTitle(QApplication::translate("DialogRGB", "Dialog", 0));
    } // retranslateUi

};

namespace Ui {
    class DialogRGB: public Ui_DialogRGB {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGRGB_H
