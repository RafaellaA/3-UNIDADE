#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QString>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //Conecta um sinal com um slot
    connect(ui->pushButton, SIGNAL(clicked(bool)),this ,SLOT(finaliza()));

    connect(ui->pushButtoncopia,SIGNAL(clicked(bool)),this, SLOT(copia()));
    //connect(ui->actionFinaliza,SIGNAL(triggered(bool)),this,SLOT(finaliza()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::finaliza()
{
    close();
}

void MainWindow::copia()
{
    QString s;
    //le o string presente no plaintextedit
    s = ui->plainTextEdit->toPlainText();
    s = "<u>" + s + "</u>";
    s = "<b>" + s + "</b>";
    //atribui ao textedit o string lido
    ui->textEdit->setText(s);
}
