#include "plotter.h"
#include <QPainter>
#include <QPen>
#include <QBrush>
#include <cmath>


Plotter::Plotter(QWidget *parent) : QWidget(parent)
{
    timerId = startTimer(50);
    teta = 0;
    vel = 1;
    ampl = 1.0;
    freq = 1;
}

void Plotter::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    QPen pen;
    QBrush brush;

    //Preparando a caneta
    //R,G,B
    pen.setColor(QColor(255,0,0));//Cor vermelha
    pen.setWidth(2);

    //Entregando a caneta ao pintor
    p.setPen(pen);

    //Preparando o pincel com a cor amarela
    brush.setColor(QColor(255,255,0));
    brush.setStyle(Qt::SolidPattern);

    //Entregando o pincel ao pintor
    p.setBrush(brush);

    p.drawRect(0,0,width(),height());

    //Colocando uma linha tracejada no meio do quadrado
    pen.setColor(QColor(0,0,255));//Cor Azul
    pen.setStyle(Qt::DashLine);
    p.setPen(pen);

    p.drawLine(0,height()/2,width(),height()/2);

    //Seno desenhado na cor Vermelha com um  pixel de largura
    pen.setColor(QColor(255,0,0));
    pen.setWidth(1);
    pen.setStyle(Qt::SolidLine);
    p.setPen(pen);

    int p1x,p1y,p2x,p2y; // quatros pontos para começar a fazer a senoide
    p1x = 0;
    p1y = height()/2;
    for(int t=0;t<width();t++){
        p2x = t;
        p2y = height()/2 - ampl*height()/2 * sin(2*3.1415*t*freq/width()+teta);
        p.drawLine(p1x,p1y,p2x,p2y);
        p1x  = p2x; p1y = p2y;
    }

}

void Plotter::timerEvent(QTimerEvent *event)
{
    teta = teta + vel;
    if(teta > 2*3.1415){
        teta = 0;
    }
    repaint();
}

void Plotter::mudaAmplitude(int a)
{
    ampl = a/99.0;
    //ativa paintevent
    repaint();
}

void Plotter::mudaFrequencia(int f)
{
    freq = f;
    repaint();
}

void Plotter::mudaVelocidade(int v)
{
    vel = v/99.0;

}
