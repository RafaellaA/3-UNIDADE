/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "plotter.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionFinaliza;
    QWidget *centralWidget;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_5;
    QSlider *horizontalSlider_Amplitude;
    QLCDNumber *lcdNumber_Amplitude;
    QHBoxLayout *horizontalLayout;
    QSlider *horizontalSlider_Frequencia;
    QLCDNumber *lcdNumber_Frequencia;
    QHBoxLayout *horizontalLayout_4;
    QSlider *horizontalSlider_Velocidade;
    QLCDNumber *lcdNumber_Velocidade;
    QVBoxLayout *verticalLayout_2;
    QTextEdit *textEdit;
    QPushButton *pushButtoncopia;
    QPlainTextEdit *plainTextEdit;
    QVBoxLayout *verticalLayout_3;
    Plotter *widget_Plotter;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_2;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1203, 648);
        actionFinaliza = new QAction(MainWindow);
        actionFinaliza->setObjectName(QStringLiteral("actionFinaliza"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 10, 1011, 551));
        horizontalLayout_2 = new QHBoxLayout(widget);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalSlider_Amplitude = new QSlider(widget);
        horizontalSlider_Amplitude->setObjectName(QStringLiteral("horizontalSlider_Amplitude"));
        horizontalSlider_Amplitude->setFocusPolicy(Qt::NoFocus);
        horizontalSlider_Amplitude->setOrientation(Qt::Horizontal);

        horizontalLayout_5->addWidget(horizontalSlider_Amplitude);

        lcdNumber_Amplitude = new QLCDNumber(widget);
        lcdNumber_Amplitude->setObjectName(QStringLiteral("lcdNumber_Amplitude"));

        horizontalLayout_5->addWidget(lcdNumber_Amplitude);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSlider_Frequencia = new QSlider(widget);
        horizontalSlider_Frequencia->setObjectName(QStringLiteral("horizontalSlider_Frequencia"));
        horizontalSlider_Frequencia->setOrientation(Qt::Horizontal);

        horizontalLayout->addWidget(horizontalSlider_Frequencia);

        lcdNumber_Frequencia = new QLCDNumber(widget);
        lcdNumber_Frequencia->setObjectName(QStringLiteral("lcdNumber_Frequencia"));

        horizontalLayout->addWidget(lcdNumber_Frequencia);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalSlider_Velocidade = new QSlider(widget);
        horizontalSlider_Velocidade->setObjectName(QStringLiteral("horizontalSlider_Velocidade"));
        horizontalSlider_Velocidade->setOrientation(Qt::Horizontal);

        horizontalLayout_4->addWidget(horizontalSlider_Velocidade);

        lcdNumber_Velocidade = new QLCDNumber(widget);
        lcdNumber_Velocidade->setObjectName(QStringLiteral("lcdNumber_Velocidade"));

        horizontalLayout_4->addWidget(lcdNumber_Velocidade);


        verticalLayout->addLayout(horizontalLayout_4);


        verticalLayout_4->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        textEdit = new QTextEdit(widget);
        textEdit->setObjectName(QStringLiteral("textEdit"));

        verticalLayout_2->addWidget(textEdit);

        pushButtoncopia = new QPushButton(widget);
        pushButtoncopia->setObjectName(QStringLiteral("pushButtoncopia"));

        verticalLayout_2->addWidget(pushButtoncopia);

        plainTextEdit = new QPlainTextEdit(widget);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));

        verticalLayout_2->addWidget(plainTextEdit);


        verticalLayout_4->addLayout(verticalLayout_2);


        horizontalLayout_2->addLayout(verticalLayout_4);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        widget_Plotter = new Plotter(widget);
        widget_Plotter->setObjectName(QStringLiteral("widget_Plotter"));

        verticalLayout_3->addWidget(widget_Plotter);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout_3->addWidget(pushButton);

        horizontalSpacer_2 = new QSpacerItem(28, 17, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout_3->addLayout(horizontalLayout_3);

        verticalLayout_3->setStretch(0, 50);

        horizontalLayout_2->addLayout(verticalLayout_3);

        MainWindow->setCentralWidget(centralWidget);
        horizontalSlider_Velocidade->raise();
        horizontalSlider_Amplitude->raise();
        lcdNumber_Velocidade->raise();
        plainTextEdit->raise();
        lcdNumber_Amplitude->raise();
        textEdit->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1203, 21));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuFile->addAction(actionFinaliza);
        mainToolBar->addAction(actionFinaliza);

        retranslateUi(MainWindow);
        QObject::connect(actionFinaliza, SIGNAL(triggered(bool)), MainWindow, SLOT(close()));
        QObject::connect(horizontalSlider_Frequencia, SIGNAL(valueChanged(int)), lcdNumber_Frequencia, SLOT(display(int)));
        QObject::connect(horizontalSlider_Velocidade, SIGNAL(valueChanged(int)), lcdNumber_Velocidade, SLOT(display(int)));
        QObject::connect(horizontalSlider_Amplitude, SIGNAL(valueChanged(int)), lcdNumber_Amplitude, SLOT(display(int)));
        QObject::connect(horizontalSlider_Frequencia, SIGNAL(valueChanged(int)), widget_Plotter, SLOT(mudaFrequencia(int)));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionFinaliza->setText(QApplication::translate("MainWindow", "Finaliza", 0));
#ifndef QT_NO_TOOLTIP
        actionFinaliza->setToolTip(QApplication::translate("MainWindow", "Finaliza o Programa", 0));
#endif // QT_NO_TOOLTIP
        actionFinaliza->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", 0));
        pushButtoncopia->setText(QApplication::translate("MainWindow", ">>>>>", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Aperte", 0));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
